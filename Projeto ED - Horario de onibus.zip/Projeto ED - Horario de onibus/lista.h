//Se o sistema for Windows adiciona determinada biblioteca, e definindo comandos de limpar e esperar
#ifdef WIN32
    #include <windows.h>
    #define LIMPA_TELA system("cls")
//Sen�o for Windows (ex.: Linux)
#else
    #include <unistd.h>
    #define LIMPA_TELA system("/usr/bin/clear")
#endif
 
//M�ximo de bytes para uma String
#define BUFFER 64
 
//Espera 3 segundos
#define ESPERA sleep(3)
 
//Estrutura da lista que ser� criada
typedef struct lista {
    char *nome;
    char horario[30];
    float preco;
    struct lista *proximo;
} Dados;

extern Dados *principal;
 
//Fun��es para manusear os dados (ir�o retornar dados)
Dados *inicia_dados  (char *nome, char horario[30], float preco);
Dados *insere_dados  (Dados *dados, char *nome, char horario[30], float preco);
Dados *delbusca_dados(Dados *dados, char *chave);
Dados *deleta_dados  (Dados *dados, int nTipo);
int   checa_vazio    (Dados *dados);
 
//Fun��es para mostrar dados
void  exibe_dados    (Dados *dados);
void  exibe_tamanho  (Dados *nova);
void  busca_dados    (Dados *dados, char *chave);
 
//Fun��es do Menu
void criavazia(void);    //1
void insereinicio(void); //2
void inserefim(void);    //3
void listavazia(void);   //4
void prielemento(void);  //5
void ultelemento(void);  //6
void exibe(void);        //7
void exibetam(void);     //8
void deletapri(void);    //9
void deleta(void);       //a
void delbusca(void);     //b
void busca(void);        //c


